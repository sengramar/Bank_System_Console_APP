﻿using System;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace _13339751_Assignment1
{
    public class Account
    {
        //attributes of account information
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Address { get; set; }
        public string Email { get; set; }
        public int AccountNum { get; set; }
        public int PhoneNum { get; set; }
        public double Balance { get; set; }

        //constructor
        public Account(int accountNum, string firstName, string lastName, string address, int phoneNum, string email, double balance)
        {
            this.AccountNum = accountNum;
            this.FirstName = firstName;
            this.LastName = lastName;
            this.Address = address;
            this.PhoneNum = phoneNum;
            this.Email = email;
            this.Balance = balance;
        }

        public Account()
        {

        }

        //update function for deposit and withdraw
        public void updateBalance(double updateValue)
        {
            Balance += updateValue;
        }

        public override string ToString()
        {
            return $"Firstname:{FirstName}\nLast Name:{LastName}\nAddress:{Address}\nPhone Number:{PhoneNum}\nEmail:{Email}\nAccount Number:{AccountNum}\nAccount Balance:{Balance}";
        }
    }
}
