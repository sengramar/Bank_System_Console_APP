﻿using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Net;
using System.Net.Mail;

namespace _13339751_Assignment1
{
    public class AccountFunction
    {
        private Account currAccount;
        private string filePath = "/Users/jiwonyou/Desktop/ANET/A1/13339751_Assignment1/13339751_Assignment1/TextFolder/";
        public AccountFunction()
        { 
            currAccount = new Account();
        } 
        //Method for creating the accountNum
        //Need to address the problem if the account has 1,2 but if 1 is deleted than it going to create with same name
        private int GetAccountNum()
        {
            try
            {
                DirectoryInfo directory = new DirectoryInfo(filePath);
                FileInfo[] f = directory.GetFiles("*", SearchOption.TopDirectoryOnly);
                //int existings = f.Length;
                //int accountNum = 100000 + existings;
                Random random = new Random();
                int accountNum = random.Next(100000, 100000000);
                return accountNum;
            }
            catch (Exception e)
            {
                Bordering.SetPos(9);
                Console.WriteLine("\nError :{0}", e.Message);
                Console.ReadKey(true);
                return -1;
            }
        }

        public void CreateAccount()
        {
            try
            {
                //CREATE ACCOUNT UI
                Title("CREATE A NEW ACCOUNT");
                Bordering.Draw(Border.TEXT, "First Name: ", false, 0);
                Bordering.Draw(Border.TEXT, "Last Name: ", false, 1);
                Bordering.Draw(Border.TEXT, "Address: ", false, 2);
                Bordering.Draw(Border.TEXT, "Phone: ", false, 3);
                Bordering.Draw(Border.TEXT, "Email: ", false, 4);
                Bordering.Draw(Border.BOT, "", false, 9);

                //Create the Account object with the input value
                currAccount = new Account(GetAccountNum(), ReadString(0), ReadString(1),
                    ReadString(2), ReadInt(3), ValidEmail(ReadString(4)), 0.0);
                //change parameter to the cursor location
                SaveFile(currAccount);
                Console.WriteLine("\n\nIs the Information correct (y/n)?");
                if (Console.ReadLine().Equals("y"))
                {
                    Console.WriteLine("\n\nAccount Created! details will be provided via email.");
                    Email.SendEmail(currAccount);
                    Console.WriteLine("Account number is:" + currAccount.AccountNum); 
                    Console.ReadKey(true);
                }
                else
                {
                    CreateAccount();
                }
                

            }
            catch (Exception e)
            {
                Bordering.SetPos(9);
                Console.WriteLine("\nError : {0}", e.Message);
                Console.ReadKey(true);
            }
            
        }
        public void SearchAccount()
        {
            try
            {
                Title("SEARCH AN ACCOUNT");
                Bordering.Draw(Border.TEXT, "Enter Account Number to be Search ", true);
                Bordering.Draw(Border.TEXT, "Account Number: ", false, 0);
                Bordering.Draw(Border.BOT, "", false, 9);
                int accountNum = ReadInt(0);
                currAccount = FindAccount(accountNum);
                if (currAccount != null)
                {
                    ShowAccountDetails(currAccount, false);
                    Console.WriteLine("\nCheck another account (y/n)?");
                    if (Console.ReadLine().Equals("y"))
                    {
                        SearchAccount();
                        Console.ReadKey(true);
                    }
                }
            }
            catch(Exception e)
            {
                Bordering.SetPos(9);
                Console.WriteLine("\nError :{0}", e.Message);
                Console.ReadKey(true);
            }
        }

        private Account FindAccount(int accountNum)
        {
            string accountFile = filePath+accountNum.ToString()+ ".txt";
            
            try
            {
                string[] record = File.ReadAllLines(accountFile);
                string firstname = record[0].Split('|')[1];
                string lastname = record[1].Split('|')[1];
                string address = record[2].Split('|')[1];
                int phoneNum = Convert.ToInt32(record[3].Split('|')[1]);
                string email = record[4].Split('|')[1];
                int balance = Convert.ToInt32(record[6].Split('|')[1]);
                currAccount = new Account(accountNum,firstname, lastname, address, phoneNum,email,balance); 
                return currAccount;
            }
            catch (FileNotFoundException)
            {
                Bordering.SetPos(9);
                Console.WriteLine("\nAccount not found!");
                Bordering.SavePos(9);
                Console.ReadKey(true);
                return null;
            }
            catch (Exception e)
            {
                Console.WriteLine("\nUnexpected Error:{0}", e.Message);
                Console.ReadKey(true);
                return null;
            }

            
        }

        public void Deposit()
        {
            try
            {
                Title("DEPOSIT");
                Bordering.Draw(Border.TEXT, "Account Number: ", false, 0);
                Bordering.Draw(Border.TEXT, "Amount: ", false, 1);
                Bordering.Draw(Border.BOT, "", false, 9);
                int accountNum = ReadInt(0);

                currAccount = FindAccount(accountNum);
                Bordering.SetPos(9);

                if (currAccount != null)
                {
                    Console.WriteLine("Enter the amount...");
                    Bordering.SavePos(9);
                }
                else
                {
                    Console.WriteLine("\nRetry (y/n)?");
                    if (Console.ReadLine().Equals("y"))
                    {
                        Deposit();
                    }
                    else
                    {
                        Console.WriteLine("Return to Menu");
                    }
                }

                int amount = ReadInt(1);
                currAccount.updateBalance(amount);
                RecordTransaction(amount);
                Bordering.SetPos(9);
                Console.WriteLine("\n"+amount + " Deposit Successful!");
                Console.ReadKey(true);
            }
            catch(Exception e)
            {
                Bordering.SetPos(9);
                Console.WriteLine("\nError :{0}", e.Message);
                Console.ReadKey(true);
            }
        }


        public void Withdraw()
        {
            try
            {
                Title("WITHDRAW");
                Bordering.Draw(Border.TEXT, "Account Number: ", false, 0);
                Bordering.Draw(Border.TEXT, "Amount: ", false, 1);
                Bordering.Draw(Border.BOT, "", false, 9);
                int accountNum = ReadInt(0);

                currAccount = FindAccount(accountNum);
                Bordering.SetPos(9);

                if (currAccount != null)
                {
                    Console.WriteLine("Enter the amount...");
                    Bordering.SavePos(9);
                }
                else
                {
                    Console.WriteLine("\nRetry (y/n)?");
                    if (Console.ReadLine().Equals("y"))
                    {
                        Withdraw();
                    }
                    else
                    {
                        Console.WriteLine("Return to Menu");
                    }
                }

                int amount = ReadInt(1);
                if (amount > currAccount.Balance)
                {
                    Bordering.SetPos(9);
                    Console.WriteLine("\nInsufficient balance Please try again");
                    Console.ReadKey();
                    Withdraw();
                }
                else
                {
                    currAccount.updateBalance(-amount);
                    RecordTransaction(-amount);
                    Bordering.SetPos(9);
                    Console.WriteLine("\n"+amount+"Withdraw Successful!");
                    Console.ReadKey(true);
                }
            }
            catch (Exception e)
            {
                Bordering.SetPos(9);
                Console.WriteLine("\nError :{0}", e.Message);
                Console.ReadKey(true);
            }

        }
        public void Statement()
        {
            try
            {
                Title("STATEMENT");
                Bordering.Draw(Border.TEXT, "Account Number: ", false, 0);
                Bordering.Draw(Border.BOT, "", false, 9);
                int accountNum = ReadInt(0);
                currAccount = FindAccount(accountNum);
                if (currAccount != null)
                {
                    ShowAccountDetails(currAccount,true);
                    Console.WriteLine("\nEmail Statement (y/n)?");
                    if (Console.ReadLine().Equals("y"))
                    {
                        Email.SendEmail(currAccount);
                        Console.WriteLine("Email sent successfully!...");
                        Console.ReadKey(true);
                    }
                    
                }
            }
            catch(Exception e)
            {
                Bordering.SetPos(9);
                Console.WriteLine("\nError : {0}", e.Message);
                Console.ReadKey(true);
            }
        }

        public void DeleteAccount()
        {
            try
            {
                Title("DELETE AN ACCOUNT");
                Bordering.Draw(Border.TEXT, "Account Number: ", false, 0);
                Bordering.Draw(Border.BOT);
                int accountNum = ReadInt(0);
                currAccount = FindAccount(accountNum);
                if (currAccount != null)
                {
                    ShowAccountDetails(currAccount, false);
                    Console.WriteLine("Delete (y/n)?");
                    if (Console.ReadLine().Equals("y"))
                    {
                        File.Delete(filePath+ accountNum + ".txt");
                        Console.WriteLine("Account Deleted!...");
                        Console.ReadKey(true);
                    }
                }
            }
            catch (Exception e)
            {
                Bordering.SetPos(9);
                Console.WriteLine("\nError :{0}", e.Message);
                Console.ReadKey(true);
            }
        }

        public string ValidEmail(string email)
        {
            string[] set = email.Split('@');
            if (set.Length == 2)
            {
                return email;
            }
            else
            {
                Bordering.SetPos(9);
                Console.WriteLine("\nInvalid Email...");
                Bordering.SetPos(4);
                Console.WriteLine("                                 ");
                return ReadString(4);

            }
        }

        public void SaveFile(Account account)
        {
            //Use reflection to access the properties.
            var accountNum = account.AccountNum;
            string filePath = Path.GetFullPath("/Users/jiwonyou/Desktop/ANET/A1/13339751_Assignment1/13339751_Assignment1/TextFolder/"+accountNum +".txt");
            try
            {
                if (!File.Exists(filePath))
                {
                    string accountinfo = currAccount.ToString();
                    var replacement = accountinfo.Replace(':', '|');
                    File.WriteAllLines(filePath, replacement.Split('\n'));
                }
                else
                {
                    Bordering.SetPos(9);
                    Console.WriteLine("\nThe File already Exist");
                    accountNum = GetAccountNum();
                }
            }
             catch (Exception e)
             {
                Bordering.SetPos(9);
                Console.WriteLine("\nError :{0}", e.Message);
             }
        }

        public void RecordTransaction(double amount)
        {
            var accountNum = currAccount.AccountNum;
            string filePath = Path.GetFullPath("/Users/jiwonyou/Desktop/ANET/A1/13339751_Assignment1/13339751_Assignment1/TextFolder/" + accountNum + ".txt");
            try
            {
                string[] records = File.ReadAllLines(filePath);
                records[6] = "Balance|"+currAccount.Balance.ToString();
                File.WriteAllLines(filePath, records);
                if (File.Exists(filePath))
                {
                    string date = DateTime.UtcNow.ToString("dd-MM-yyyy");
                    // Create deposit transaction string
                    if (amount > 0)
                    {
                        string transaction = date + "|Deposit|" + amount +"|"+ currAccount.Balance;
                        File.AppendAllText(filePath, transaction);

                    }
                    else
                    {
                        string transaction = date + "|WithDraw|" + amount + "|" + currAccount.Balance;
                        File.AppendAllText(filePath, transaction);
                    }
                }
            }
            catch(Exception e)
            {
                Bordering.SetPos(9);
                Console.WriteLine("\nError :{0}", e.Message);
            }
        }

        //create the method for the title for each function 
        public static void Title(string option)
        {
            Console.Clear();
            Bordering.Draw(Border.TOP);
            Bordering.Draw(Border.TEXT, option, true);
            Bordering.Draw(Border.TEXT);
            Bordering.Draw(Border.TEXT, "ENTER THE DETAILS", true);
            Bordering.Draw(Border.TEXT, "  ", true);
        }

        //create the UI for showing the account details
        private void ShowAccountDetails(Account account, bool isStatement = false)
        {
            if (account != null)
            {
                Bordering.Draw(Border.BOT);


                if (isStatement)
                {
                    Console.WriteLine("\n\nAccount found! The statement is displayed below...");
                    Bordering.Draw(Border.TOP);
                    Bordering.Draw(Border.TEXT, "SIMPLE BANKING SYSTEM", true);
                    Bordering.Draw(Border.TEXT);
                    Bordering.Draw(Border.TEXT, "Account Statement");
                }
                else
                {
                    Console.WriteLine("\n\nAccount found!");
                    Bordering.Draw(Border.TOP);
                    Bordering.Draw(Border.TEXT, "ACCOUNT DETAILS", true);
                    Bordering.Draw(Border.TEXT);
                }
                Bordering.Draw(Border.TEXT, "  ");
                Bordering.Draw(Border.TEXT, "Account No: " + account.AccountNum);
                Bordering.Draw(Border.TEXT, "Account Balance: $" + account.Balance);
                Bordering.Draw(Border.TEXT, "First Name: " + account.FirstName);
                Bordering.Draw(Border.TEXT, "Last Name: " + account.LastName);
                Bordering.Draw(Border.TEXT, "Address: " + account.Address);
                Bordering.Draw(Border.TEXT, "Phone: " + account.PhoneNum);
                Bordering.Draw(Border.TEXT, "Email: " + account.Email);
                Bordering.Draw(Border.BOT, "", false, 9);
            }
        }

        //read the string into another data type
        public string ReadString(int pos)
        {
            try
            {
                Bordering.SetPos(pos);
                return Console.ReadLine();
            }
            catch (FormatException)
            {
                Bordering.SetPos(9);
                Console.WriteLine("\nWrong datatype.. Please type characters");
                Bordering.SetPos(pos);
                Console.WriteLine("                                 ");
                return ReadString(pos);
            }
            catch (Exception e)
            {
                Bordering.SetPos(9);
                Console.WriteLine("\nUnexpected Error: {0]", e.Message);
                Bordering.SetPos(pos);
                Console.WriteLine("                                 ");
                return ReadString(pos);
            }
        }

        public double ReadDouble(int pos)
        {
            try
            {
                Bordering.SetPos(pos);
                return Convert.ToDouble(Console.ReadLine());
            }

            catch (FormatException)
            {
                Bordering.SetPos(9);
                Console.WriteLine("\nWrong datatype.. Please type double");
                Bordering.SetPos(pos);
                Console.WriteLine("                                 ");
                return ReadDouble(pos);
            }
            catch (Exception e)
            {
                Bordering.SetPos(9);
                Console.WriteLine("\nUnexpected Error: {0]", e.Message);
                Bordering.SetPos(pos);
                Console.WriteLine("                                 ");
                return ReadDouble(pos);
            }
        }

        private int ReadInt(int pos)
        {
            try
            {
                Bordering.SetPos(pos);
                return Convert.ToInt32(Console.ReadLine());
            }
            catch (FormatException)
            {
                Bordering.SetPos(9);
                Console.WriteLine("\nWrong datatype.. Please type numbers");
                Bordering.SetPos(pos);
                Console.WriteLine("                                 ");
                return ReadInt(pos);
            }
            catch (Exception e)
            {
                Bordering.SetPos(9);
                Console.WriteLine("\nUnexpected Error: {0]", e.Message);
                Bordering.SetPos(pos);
                Console.WriteLine("                                 ");
                return ReadInt(pos);
            }
        }
    }
}
