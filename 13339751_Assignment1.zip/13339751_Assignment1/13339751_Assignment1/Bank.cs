﻿using System;
namespace _13339751_Assignment1
{
    public class Bank
    {
        //attribute
        private User user;
        private AccountFunction accountFunction;
        private bool loginStatus = false;


        public Bank(User user)
        {
            this.user = user;
            this.accountFunction = new AccountFunction();
        }

        //main menu system
        public void MenuUI()
        {
            Console.Clear();
            Bordering.Draw(Border.TOP);
            Bordering.Draw(Border.TEXT, "WELCOME TO SIMPLE BANKING SYSTEM", true);
            Bordering.Draw(Border.TEXT);
            Bordering.Draw(Border.TEXT, "1. Create a new accont");
            Bordering.Draw(Border.TEXT, "2. Search for an accont");
            Bordering.Draw(Border.TEXT, "3. Deposit");
            Bordering.Draw(Border.TEXT, "4. Withdraw");
            Bordering.Draw(Border.TEXT, "5. A/C statement");
            Bordering.Draw(Border.TEXT, "6. Delete account");
            Bordering.Draw(Border.TEXT, "7. Exit");
            Bordering.Draw(Border.TEXT);
            Bordering.Draw(Border.TEXT, "Enter your choice (1-7): ", false, 0);
            Bordering.Draw(Border.BOT, "", false, 9);
            Bordering.SetPos(0);
        }

        public void Menu()
        {
            try
            {
                if (!loginStatus)
                {
                    user.Login();
                    loginStatus = true;              
                }
                MenuUI();
                switch (Convert.ToInt32(Console.ReadLine()))
                {
                    case 1:
                        accountFunction.CreateAccount();
                        Menu();
                        break;
                    case 2:
                        accountFunction.SearchAccount();
                        Menu();
                        break;
                    case 3:
                        accountFunction.Deposit();
                        Menu();
                        break;
                    case 4:
                        accountFunction.Withdraw();
                        Menu();
                        break;
                    case 5:
                        accountFunction.Statement();
                        Menu();
                        break;
                    case 6:
                        accountFunction.DeleteAccount();
                        Menu();
                        break;
                    case 7:
                        Exit();
                        break;
                    default:
                        Error();
                        Menu();
                        break;
                }

            }
            catch (FormatException)
            {
                Console.WriteLine("\nInproper formatting");
                Console.ReadKey(true);
                Menu();
            }
        }
        //logout
        public void Exit()
        {
            loginStatus = false;
            user.Login();
        }

        public void Error()
        {
            Console.WriteLine("\n Cannot processed with the input");
            Console.WriteLine("\n Please select the options above");
            Console.WriteLine("\n Return to Menu");
        }
    }
}
