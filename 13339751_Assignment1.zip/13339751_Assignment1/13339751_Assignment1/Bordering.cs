﻿using System;
using System.Collections.Generic;

namespace _13339751_Assignment1
{
    //create enum class of identifies which border to create
    public enum Border
    {
        TOP,BOT,TEXT
    }

    public class Bordering
    {
        //constructor is removed as the readonly field can't be assigned after the constructor exits

        //attributes for making border
        public static int[,] pos = new int[10, 2];
        private readonly static int len = 60;

        //Console.CursorLeft; = row
        //Console.CursorTop; = col
        public static void SavePos(int index)
        {
            pos[index, 0] = Console.CursorLeft;
            pos[index, 1] = Console.CursorTop;
        }

        public static int[] GetPos(int index)
        {
            int[] list = new int[2];
            list[0] = pos[index, 0];
            list[1] = pos[index, 1];
            return list;
        }

        public static void SetPos(int index)
        {
            Console.SetCursorPosition(pos[index,0],pos[index,1]);
        }


        //method for drawing the line for the border
        private static void DrawLine(char[] edge, string text, bool isCentre, int index)
        { 
            string padding = "";
            if (text == "")
            {
                Console.Write(edge[0]);
                for (int i = 0; i < len; i++)
                {
                    Console.Write('═');
                }
                Console.WriteLine(edge[1]);
                if (index >= 0)
                {
                    SavePos(index);
                }
            }
            else
            {
                if (isCentre)
                {
                    for (int i = 0; i<(len - text.Length)/2; i++)
                    {
                        padding += " ";
                    }
                }

                else
                {
                    padding += "       ";
                }

                Console.Write(edge[0]);
                Console.Write(padding + text);
                if (index >= 0)
                {
                    SavePos(index);
                }
                //calculating the empty space = overall length - padding lenth - text length
                for (int i = 0; i < len - padding.Length - text.Length; i++)
                {
                    Console.Write(" ");
                }
                Console.WriteLine(edge[1]);
            }

        }


        public static void Draw(Border borderType, string text = "",bool isCentre = false, int index = -1)
        {
            char[] edge = new char[2];
            switch (borderType)
            {
                case Border.TOP:
                    edge[0] = '╔';
                    edge[1] = '╗';
                    break;
                case Border.BOT:
                    edge[0] = '╚';
                    edge[1] = '╝';
                    break;
                case Border.TEXT:
                    edge[0] = '|';
                    edge[1] = '|';
                    break;
                default:
                    break;
            }

            DrawLine(edge, text, isCentre, index);
        }
        
    }
}
