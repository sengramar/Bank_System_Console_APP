﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net.Mail;
using System.IO;

namespace _13339751_Assignment1
{
    public class Email
    {
        static MailAddress sender = new MailAddress("mylifeiscloudy@gmail.com", "Bank");
        static SmtpClient client = new SmtpClient()
        {
            Host = "smtp.gmail.com",
            Port = 587,
            UseDefaultCredentials = false,
            EnableSsl = true,
            DeliveryMethod = SmtpDeliveryMethod.Network,
            Credentials = new System.Net.NetworkCredential("mylifeiscloudy@gmail.com", "abc123cba")

        };
        public static void SendEmail(Account account)
        {
            
            string text = account.ToString();
            string email = account.Email;
            MailAddress toAddress = new MailAddress(email);
            MailMessage message = new MailMessage(sender, toAddress);
            message.Subject = "Account statement from basic banking application!";
            message.Body = text;
            client.Send(message);
            message.Dispose();
        }
    }
}
