﻿using System;

namespace _13339751_Assignment1
{
    class Program
    {

        static void Main(string[] args)
        {
            User user = new("/Users/jiwonyou/Desktop/ANET/A1/13339751_Assignment1/13339751_Assignment1/TextFolder/login.txt");
            Bank bank = new Bank(user);
            bank.Menu();
            Console.ReadKey();
         }
    }
}
