﻿using System;
using System.IO;

namespace _13339751_Assignment1
{
    public class User
    {
        private string userName;
        private string password;
        private string[] record;

        public User(string file)
        {
            record = File.ReadAllLines(file);
        }

        public static void LoginUI()
        {
            Console.Clear();
            Bordering.Draw(Border.TOP);
            Bordering.Draw(Border.TEXT, "WELCOME TO SIMPLE BANKING SYSTEM", true);
            Bordering.Draw(Border.TEXT);
            Bordering.Draw(Border.TEXT, "LOGIN TO START", true);
            Bordering.Draw(Border.TEXT, "  ", true);
            Bordering.Draw(Border.TEXT, "User Name: ", false, 0);
            Bordering.Draw(Border.TEXT, "Password: ", false, 1);
            Bordering.Draw(Border.BOT, "", false, 9);
        }

        public void Login()
        {
            LoginUI();
            //get the input value 
            Bordering.SetPos(0); userName = Console.ReadLine();
            Bordering.SetPos(1); PasswordEncryption();

            //To write outside the border
            Bordering.SetPos(9);
            Console.WriteLine("");
            if (UserExists(userName))
            {
                if (Validate(userName, password))
                {
                    Console.WriteLine("Valid credentials!... Please enter");
                    Console.ReadKey(true);
                }
                else
                {
                    Console.WriteLine("Incorrect Password Please try again");
                    Console.ReadKey(true);
                    Login();
                }
            }
            else
            {
                Console.WriteLine("Username doesn't exist");
                Console.ReadKey(true);
                Login();
            }

        }

        //check if the user exist in the file(for search)
        private bool UserExists(string userName)
        {
            foreach (string set in record)
            {
                string[] splits = set.Split('|');
                if (splits[0] == userName)
                {
                    return true;
                }
            }
            return false;
        }

        //login
        private bool Validate(string userName, string password)
        {
            foreach (string set in record)
            {
                string[] splits = set.Split('|');
                if (splits[0] == userName && splits[1] == password)
                {
                    return true;
                }
            }
            return false;
        }


        //turning the password into '*' 
        private void PasswordEncryption()
        {
            ConsoleKeyInfo currentKeyInfo = new ConsoleKeyInfo();
            string value = "";
            int[] currentPos = Bordering.GetPos(1);
            while (currentKeyInfo.Key != ConsoleKey.Enter)
            {
                currentKeyInfo = Console.ReadKey(true);
                if (currentKeyInfo.Key == ConsoleKey.Backspace)
                {
                    if (Console.CursorLeft > currentPos[0])
                    {
                        Console.SetCursorPosition(Console.CursorLeft - 1, Console.CursorTop);
                        Console.Write(" ");
                        Console.SetCursorPosition(Console.CursorLeft - 1, Console.CursorTop);
                        value = value.Remove(value.Length - 1);
                    }
                }
                else if (currentKeyInfo.Key != ConsoleKey.Enter)
                {
                    Console.Write("*");
                    value += currentKeyInfo.KeyChar;
                }
            }
            password = value;
        }
    }
}
